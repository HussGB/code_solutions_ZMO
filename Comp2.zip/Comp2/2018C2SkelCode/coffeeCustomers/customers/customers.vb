﻿Imports System.IO

Public Class customers



    ' . . . Is broken or incomplete code. Complete this code.

    Private Structure customer
        Public customerID As String
        Public firstName As String
        Public surname As String
        Public postcode As String
        Public pointsCollected As String
    End Structure


    Private Sub cmd .... _Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        Dim customerData As New customer
        Dim sw As New System.IO.StreamWriter("customers.txt", True)
        customerData.customerID = LSet(txtCustomerID.Text, 50)
        customerData.firstName = LSet(txtFirstName.Text, 50)
        customerData.surname = LSet(txtSurname.Text, 50)
        customerData.postcode = LSet(txtPostcode.Text, 50)
        customerData.pointsCollected = LSet(txtPointsCollected.Text, 50)

        sw.WriteLine(customerData.customerID & customerData.firstName & customerData.surname & customerData.postcode & customerData.pointsCollected)
        sw.Close()
        MsgBox("File Saved!")

    End Sub

    Private Sub customers_Load() Handles MyBase.Load
        If Dir$("customers.txt") = "" Then
            Dim sw As New StreamWriter("customers.txt", True)
            sw.WriteLine("")
            sw.Close()
            MsgBox("A new file has been created", vbExclamation, "Warning!")
        End If
    End Sub

    Private Sub cmd.... _Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCount.Click
        Dim CountGot As Integer
        CountGot = 0
        Dim customerCount As Integer
        customerCount = 0

        Dim CustomerData() As String = File.ReadAllLines("customers.txt")
        For i = 0 To UBound(CustomerData)

            CountGot = 0
            If Trim(Mid(CustomerData(i), 1, 50)) = txtCustomerID.Text And Not txtCustomerID.Text = "" Then CountGot = CountGot + 1
            If Trim(Mid(CustomerData(i), 51, 50)) = txtFirstName.Text And Not txtFirstName.Text = "" Then CountGot = CountGot + 1
            If Trim(Mid(CustomerData(i), 101, 50)) = txtSurname.Text And Not txtSurname.Text = "" Then CountGot = CountGot + 1
            If Trim(Mid(CustomerData(i), 151, 50)) = txtPostcode.Text And Not txtPostcode.Text = "" Then CountGot = CountGot + 1
            If Trim(Mid(CustomerData(i), 201, 50)) = txtPointsCollected.Text And Not txtPointsCollected.Text = "" Then CountGot = CountGot + 1
            If CountGot > 0 Then customerCount = customerCount + 1
        Next i
        .....("There were: " & ....... & " items found")

    End Sub



End Class
