﻿Imports System.IO
Public Class CoffeeCalculator
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        txtResult.Text = CInt(txtNum1.Text) + CInt(txtNum2.Text)
        Dim sw As New System.IO.StreamWriter("calcmemory.txt", True)
        sw.WriteLine(txtResult.Text)
        sw.Close()
        MsgBox("Result stored.")

    End Sub

    Private Sub btnSubtract_Click(sender As Object, e As EventArgs) Handles btnSubtract.Click
        txtResult.Text = txtNum1.Text - txtNum2.Text
        Dim sw As New System.IO.StreamWriter("calcmemory.txt", True)
        sw.WriteLine(txtResult.Text)
        sw.Close()
        MsgBox("Result stored.")
    End Sub

    Private Sub btnRetrieve_Click(sender As Object, e As EventArgs) Handles btnRetrieve.Click
        Dim calculations() As String = System.IO.File.ReadAllLines("calcmemory.txt")
        Dim lastVal As Integer

        lastVal = UBound(calculations)
        txtLastResult.Text = calculations(lastVal)

    End Sub
End Class