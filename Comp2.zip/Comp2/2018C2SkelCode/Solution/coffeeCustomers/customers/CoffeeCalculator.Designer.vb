﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CoffeeCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtNum1 = New System.Windows.Forms.TextBox()
        Me.txtNum2 = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnSubtract = New System.Windows.Forms.Button()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.btnRetrieve = New System.Windows.Forms.Button()
        Me.txtLastResult = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'txtNum1
        '
        Me.txtNum1.Location = New System.Drawing.Point(12, 12)
        Me.txtNum1.Name = "txtNum1"
        Me.txtNum1.Size = New System.Drawing.Size(113, 20)
        Me.txtNum1.TabIndex = 0
        Me.txtNum1.Text = "Enter a number"
        '
        'txtNum2
        '
        Me.txtNum2.Location = New System.Drawing.Point(12, 56)
        Me.txtNum2.Name = "txtNum2"
        Me.txtNum2.Size = New System.Drawing.Size(113, 20)
        Me.txtNum2.TabIndex = 0
        Me.txtNum2.Text = "Enter another number"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(152, 12)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 1
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnSubtract
        '
        Me.btnSubtract.Location = New System.Drawing.Point(152, 54)
        Me.btnSubtract.Name = "btnSubtract"
        Me.btnSubtract.Size = New System.Drawing.Size(75, 23)
        Me.btnSubtract.TabIndex = 1
        Me.btnSubtract.Text = "Subtract"
        Me.btnSubtract.UseVisualStyleBackColor = True
        '
        'txtResult
        '
        Me.txtResult.Location = New System.Drawing.Point(249, 14)
        Me.txtResult.Multiline = True
        Me.txtResult.Name = "txtResult"
        Me.txtResult.Size = New System.Drawing.Size(103, 62)
        Me.txtResult.TabIndex = 0
        Me.txtResult.Text = "Result"
        Me.txtResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnRetrieve
        '
        Me.btnRetrieve.Location = New System.Drawing.Point(378, 11)
        Me.btnRetrieve.Name = "btnRetrieve"
        Me.btnRetrieve.Size = New System.Drawing.Size(75, 23)
        Me.btnRetrieve.TabIndex = 2
        Me.btnRetrieve.Text = "Retrieve"
        Me.btnRetrieve.UseVisualStyleBackColor = True
        '
        'txtLastResult
        '
        Me.txtLastResult.Location = New System.Drawing.Point(378, 40)
        Me.txtLastResult.Multiline = True
        Me.txtLastResult.Name = "txtLastResult"
        Me.txtLastResult.Size = New System.Drawing.Size(75, 36)
        Me.txtLastResult.TabIndex = 0
        Me.txtLastResult.Text = "Last Result"
        Me.txtLastResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CoffeeCalculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(488, 92)
        Me.Controls.Add(Me.btnRetrieve)
        Me.Controls.Add(Me.btnSubtract)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.txtNum2)
        Me.Controls.Add(Me.txtLastResult)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.txtNum1)
        Me.Name = "CoffeeCalculator"
        Me.Text = "CoffeeCalculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtNum1 As TextBox
    Friend WithEvents txtNum2 As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnSubtract As Button
    Friend WithEvents txtResult As TextBox
    Friend WithEvents btnRetrieve As Button
    Friend WithEvents txtLastResult As TextBox
End Class
