Public Class Form1

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        ' coding for the OK command button
        ' displays an appropriate message for each possible number entered
        ' written by A. Programmer on 19/05/09

        Dim Number As Integer

        Number = txtNumber.Text

        If Number = 1 Then MsgBox(Number & " wins you a colour TV")
        If Number = 2 Then MsgBox(Number & " wins you a mobile phone")
        If Number = 3 Then MsgBox(Number & " wins you a holiday in Spain")
        If Number = 4 Then MsgBox(Number & " wins you 10p")
        If Number = 5 Then MsgBox(Number & " wins you a day at the beach")

        If Number < 1 Then MsgBox(Number & " is too small")
        If Number > 5 Then MsgBox(Number & " is too large")


    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtNumber.Text = ""
    End Sub
End Class
