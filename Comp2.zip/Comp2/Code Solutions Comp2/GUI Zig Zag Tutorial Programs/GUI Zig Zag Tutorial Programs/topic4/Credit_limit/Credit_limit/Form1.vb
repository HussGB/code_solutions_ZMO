Public Class Form1

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        ' coding for the OK command button
        ' warns the user if the amount is over the credit limit (�100)
        ' written by A. Programmer on 19/05/09

        Dim Number As Single

        Number = txtInput.Text

        If Number <= 100 Then MsgBox("withdrawal approved") Else _
  MsgBox(Number & " is over you credit limit")

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtInput.Text = ""
    End Sub
End Class
