Public Class Form1

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        ' coding for the OK command button
        ' displays an appropriate message for each grade letter entered 
        ' and changes the form colour
        ' written by A. Programmer on 29/03/07

        Dim Grade As String

        Grade = txtGrade.text

        If Grade = "A" Then
            Me.BackColor = Color.Red
            MsgBox(Grade & " means you got over 70%")
        End If

        If Grade = "B" Then
            Me.BackColor = Color.Blue
            MsgBox(Grade & " means you got between 60% and 70%")
        End If

        If Grade = "C" Then
            Me.BackColor = Color.Green
            MsgBox(Grade & " means you got between 50% and 60%")
        End If

        If Grade = "D" Then
            Me.BackColor = Color.Yellow
            MsgBox(Grade & " means you got between 40% and 50%")
        End If

        If Grade = "F" Then
            Me.BackColor = Color.Black
            MsgBox(Grade & " means that you got less than 40%")
        End If

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtGrade.Text = ""
        Me.BackColor = Color.Gainsboro
    End Sub
End Class
