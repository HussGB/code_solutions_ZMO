Public Class Form1

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        ' coding for the OK command button
        ' displays an appropriate message for each number   
        ' and changes the form colour
        ' written by A. Programmer on 19/05/09

        Dim Number As Integer

        Number = txtNumber.Text

        If Number = 1 Then
            Me.BackColor = Color.Red
            MsgBox(Number & " wins you a colour TV")
        End If

        If Number = 2 Then
            Me.BackColor = Color.Blue
            MsgBox(Number & " wins you a mobile phone")
        End If

        If Number = 3 Then
            Me.BackColor = Color.Green
            MsgBox(Number & " wins you a holiday in Spain")
        End If

        If Number = 4 Then
            Me.BackColor = Color.Yellow
            MsgBox(Number & " wins you 10p")
        End If

        If Number = 5 Then
            Me.BackColor = Color.Gold
            MsgBox(Number & " wins you a day at the beach")
        End If

        If Number < 1 Then MsgBox(Number & " is too small")
        If Number > 5 Then MsgBox(Number & " is too large")

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtNumber.Text = ""
        Me.BackColor = Color.Gainsboro
    End Sub
End Class
