Public Class Form1

    
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtMax.Text = ""
        txtMark.Text = ""
        txtName.text = ""
        txtSurname.Text = ""
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        ' code for the OK button
        ' by A. Programmer 21/04/09
        ' variable declarations
        Dim max_mark, mark As Integer
        Dim first_name, surname, grade, init, display_name As String
        Dim percent As Single

        ' store user inputs
        max_mark = txtMax.Text
        first_name = txtName.Text
        surname = txtSurname.Text
        mark = txtMark.Text

        ' calculate percentage mark
        percent = (mark / max_mark) * 100

        ' calculate grade
        If percent >= 80 Then grade = "A+"
        If percent >= 70 And percent < 80 Then grade = "A"
        If percent >= 60 And percent < 70 Then grade = "B"
        If percent >= 50 And percent < 60 Then grade = "C"
        If percent >= 45 And percent < 50 Then grade = "D"
        If percent < 45 Then grade = "fail"

        ' create display name
        init = Mid$(first_name, 1, 1)
        display_name = init + ". " + surname

        ' display message in format A.Einstein, 42/60, 70%, grade A
        MsgBox(display_name & ", " & mark & "/" & max_mark & ", " & Format(percent, ".0") & "%, " & "grade " & grade)

    End Sub
End Class
