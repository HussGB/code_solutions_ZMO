Public Class Form1

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtEnter.Text = " "
        txtResult.Text = " "
    End Sub

    Private Sub btnFunction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFunction.Click
        Dim string_in As String
        Dim number_out As Integer
        string_in = txtEnter.Text
        number_out = Len(string_in)
        txtResult.Text = number_out
    End Sub
End Class
