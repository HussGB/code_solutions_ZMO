Public Class Form1

    Private Sub btnPassword_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPassword.Click
        'coding for the Password command button
        'by A. Programmer on 21/04/09

        Dim name1, name2, year, colour, street, shoe_size, password As String

        name1 = InputBox("Enter your first name")
        name1 = Mid$(name1, 1, 1)

        name2 = InputBox("Enter your surname")
        name2 = Mid$(name2, 2, 1)

        year = InputBox("Enter your birth year (e.g. 1993)")
        year = Mid$(year, 3, 3)

        colour = InputBox("Enter your favourite colour")
        colour = Mid$(colour, 2, 2)

        street = InputBox("Enter the name of the street where you live")
        street = Mid$(street, 1, 3)

        shoe_size = InputBox("Enter your shoe size")

        password = name1 + name2 + year + colour + street + shoe_size


        MsgBox("Your password is " & password)

    End Sub
End Class
