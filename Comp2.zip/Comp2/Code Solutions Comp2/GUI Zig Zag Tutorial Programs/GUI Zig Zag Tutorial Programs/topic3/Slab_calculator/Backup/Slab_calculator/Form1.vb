Public Class Form1

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click

        ' code for the Calculate command button
        ' by A. Programmer  19/05/09

        Dim wide, deep As Integer
        Dim slab_cost As Single
        Dim no_of_slabs As Integer
        Dim total_cost As Single

        wide = txtWide.Text
        deep = txtDeep.Text
        slab_cost = txtCost.Text

        no_of_slabs = wide * deep
        total_cost = no_of_slabs * slab_cost

        txtTotalNumber.Text = no_of_slabs
        txtTotalCost.Text = Format(total_cost, "currency")

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        ' clears all text boxes
        txtWide.Text = ""
        txtDeep.Text = ""
        txtCost.Text = ""
        txtTotalNumber.Text = ""
        txtTotalCost.Text = ""

    End Sub
End Class
