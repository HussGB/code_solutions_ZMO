Public Class Form1

    Private Sub btnFunction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFunction.Click
        Dim number, result As Single

        number = txtEnter.Text

        result = System.Math.Sin(number * 3.14128 / 180)

        txtResult.Text = result

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtEnter.Text = ""
        txtResult.Text = ""
    End Sub
End Class
