Public Class Form1

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        'distance, speed and time program
        'code for the start command button
        'by A. Programmer on 20/04/09

        Dim start_town As String
        Dim end_town As String
        Dim distance As Integer
        Dim av_speed As Integer
        Dim time_taken As Single

        start_town = InputBox("Where are you travelling from?")
        end_town = InputBox("Where are you going?")
        distance = InputBox("How far is it (to the nearest km)?")
        av_speed = InputBox("What is your average speed (to the nearest km/hour)")

        time_taken = distance / av_speed

        txtStartEnd.Text = "From: " & start_town & vbCrLf & "To: " & end_town
        txtDST.Text = "Distance: " & distance & " km" & vbCrLf & "Av. speed: " & av_speed & "km/hr" & vbCrLf & "Time: " & Format(time_taken, "#0.0\hrs")

    End Sub
End Class
