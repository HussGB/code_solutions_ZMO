Public Class Form1



    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        ' code for the start command button
        ' by A. Programmer on 20/04/09

        Dim runners_name As String
        Dim which_event As String
        Dim squad_number As Integer
        Dim time_1 As Single
        Dim time_2 As Single
        Dim time_3 As Single
        Dim average As Single

        runners_name = InputBox("Enter the runner's name")
        squad_number = InputBox("Enter the runner's number")
        which_event = InputBox("Which event?")

        time_1 = InputBox("Time in 1st race")
        time_2 = InputBox("Time in 2nd race")
        time_3 = InputBox("Time in 3rd race")

        average = (time_1 + time_2 + time_3) / 3

        txtDetails.Text = "Name:  " & runners_name & vbCrLf & _
        "Number:  " & squad_number & vbCrLf & "Event:  " & which_event
        txtAverage.Text = Format(average, ".00\ s")

    End Sub
End Class
