Public Class Form1

    Private Sub btnMessage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMessage.Click
        'code for the Message button
        'by A. Programmer on 17/05/09

        Dim name As String

        name = txtName.Text

        lblMessage.Text = "welcome to VB, " & name
    End Sub
End Class
