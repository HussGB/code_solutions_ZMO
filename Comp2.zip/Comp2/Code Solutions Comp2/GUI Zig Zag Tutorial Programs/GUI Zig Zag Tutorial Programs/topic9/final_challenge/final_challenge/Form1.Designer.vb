<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtMemNum = New System.Windows.Forms.TextBox
        Me.txtSurname = New System.Windows.Forms.TextBox
        Me.txtFirstName = New System.Windows.Forms.TextBox
        Me.txtFull = New System.Windows.Forms.TextBox
        Me.txtOwed = New System.Windows.Forms.TextBox
        Me.btnFile = New System.Windows.Forms.Button
        Me.btnClear = New System.Windows.Forms.Button
        Me.btnReadFile = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 65)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter the details" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for 1 member," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "then click the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & """send to file""" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "button"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(158, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(102, 130)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Member number" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Surname" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "First Name" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Full member?" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(0 for No, -1 for Yes)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Amount Owed (�)"
        '
        'txtMemNum
        '
        Me.txtMemNum.Location = New System.Drawing.Point(266, 6)
        Me.txtMemNum.Name = "txtMemNum"
        Me.txtMemNum.Size = New System.Drawing.Size(78, 20)
        Me.txtMemNum.TabIndex = 2
        '
        'txtSurname
        '
        Me.txtSurname.Location = New System.Drawing.Point(266, 32)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(100, 20)
        Me.txtSurname.TabIndex = 3
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(266, 58)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(100, 20)
        Me.txtFirstName.TabIndex = 4
        '
        'txtFull
        '
        Me.txtFull.Location = New System.Drawing.Point(266, 84)
        Me.txtFull.Name = "txtFull"
        Me.txtFull.Size = New System.Drawing.Size(50, 20)
        Me.txtFull.TabIndex = 5
        '
        'txtOwed
        '
        Me.txtOwed.Location = New System.Drawing.Point(266, 116)
        Me.txtOwed.Name = "txtOwed"
        Me.txtOwed.Size = New System.Drawing.Size(50, 20)
        Me.txtOwed.TabIndex = 6
        '
        'btnFile
        '
        Me.btnFile.Location = New System.Drawing.Point(15, 87)
        Me.btnFile.Name = "btnFile"
        Me.btnFile.Size = New System.Drawing.Size(54, 49)
        Me.btnFile.TabIndex = 7
        Me.btnFile.Text = "send record to file"
        Me.btnFile.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(344, 87)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(54, 49)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "clear text boxes"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnReadFile
        '
        Me.btnReadFile.Location = New System.Drawing.Point(85, 87)
        Me.btnReadFile.Name = "btnReadFile"
        Me.btnReadFile.Size = New System.Drawing.Size(54, 49)
        Me.btnReadFile.TabIndex = 9
        Me.btnReadFile.Text = "read data from file"
        Me.btnReadFile.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(410, 152)
        Me.Controls.Add(Me.btnReadFile)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnFile)
        Me.Controls.Add(Me.txtOwed)
        Me.Controls.Add(Me.txtFull)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.txtSurname)
        Me.Controls.Add(Me.txtMemNum)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "filing a record"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtMemNum As System.Windows.Forms.TextBox
    Friend WithEvents txtSurname As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents txtFull As System.Windows.Forms.TextBox
    Friend WithEvents txtOwed As System.Windows.Forms.TextBox
    Friend WithEvents btnFile As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnReadFile As System.Windows.Forms.Button

End Class
