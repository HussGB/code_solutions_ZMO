Public Class Form1

    Private Sub btnWriteFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWriteFile.Click
        Dim Filename As String
        Filename = InputBox("Please enter a filename")
        FileOpen(1, Filename, OpenMode.Output)
        Print(1, txtData.Text)
        FileClose(1)
    End Sub

    Private Sub btnReadFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReadFile.Click
        Dim Filename, storedtext As String
        Filename = InputBox("Please enter a filename")
        FileOpen(1, Filename, OpenMode.Input)
        storedtext = LineInput(1)
        txtData.Text = storedtext
        FileClose(1)
    End Sub

    Private Sub btnDeleteFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteFile.Click
        Dim Filename As String
        Dim response As Boolean
        Filename = InputBox("Please enter a filename")
        Response = MsgBox("Are you sure you want to delete " & filename, vbYesNo)
        If response = vbYes Then Kill(Filename)
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtData.Text = " "
    End Sub

    Private Sub btnAppendFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAppendFile.Click
        Dim Filename As String
        Dim Howmany, Counter As Integer
        Dim data_item As String
        Filename = InputBox("Please enter a filename")
        FileOpen(1, Filename, OpenMode.Append)
        Howmany = InputBox("How many data items to be added")
        For Counter = 1 To Howmany
            data_item = InputBox("Enter data item")
            Print(1, data_item)
        Next
        FileClose(1)
    End Sub
End Class
