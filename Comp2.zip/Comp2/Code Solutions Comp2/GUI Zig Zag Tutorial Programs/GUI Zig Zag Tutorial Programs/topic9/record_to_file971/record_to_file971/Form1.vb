Public Class Form1
    Structure MemberType
        Dim MemberNumber As Integer
        <VBFixedString(20)> Dim Surname As String
        <VBFixedString(20)> Dim Forename As String
        Dim FullMember As Boolean
        Dim Owed As Single
    End Structure

    Private Sub btnFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFile.Click
        Dim Members As MemberType
        Dim filename As String

        Members.MemberNumber = txtMemNum.Text
        Members.Surname = txtSurname.Text
        Members.Forename = txtFirstName.Text
        Members.FullMember = txtFull.Text
        Members.Owed = txtOwed.Text

        filename = InputBox("please enter a filename, including path")
        FileOpen(1, filename, OpenMode.Random, , , Len(Members))
        FilePut(1, Members, )
        FileClose(1)
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtMemNum.Text = ""
        txtSurname.Text = ""
        txtFirstName.Text = ""
        txtFull.Text = ""
        txtOwed.Text = ""
    End Sub

    Private Sub btnReadFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReadFile.Click
        Dim Members As MemberType
        Dim filename As String

        filename = InputBox("please enter a filename, including path")
        FileOpen(1, filename, OpenMode.Random, , , Len(Members))
        FileGet(1, Members)
        FileClose(1)

        txtMemNum.Text = Members.MemberNumber
        txtSurname.Text = Members.Surname
        txtFirstName.Text = Members.Forename
        txtFull.Text = Members.FullMember
        txtOwed.Text = Members.Owed

    End Sub
End Class
