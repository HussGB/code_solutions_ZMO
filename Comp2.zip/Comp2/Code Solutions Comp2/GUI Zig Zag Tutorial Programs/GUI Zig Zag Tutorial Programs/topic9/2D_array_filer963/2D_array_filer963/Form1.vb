Public Class Form1
    Dim Numbers(2, 3) As Integer
    Dim i, j As Integer
    Dim Filename As String

    Private Sub btnDisplayArray_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplayArray.Click

        'Display array in 4 list boxes

        For i = 0 To 2
            lstColumn0.Items.Add(Numbers(i, 0))
        Next i
        For i = 0 To 2
            lstColumn1.Items.Add(Numbers(i, 1))
        Next i
        For i = 0 To 2
            lstColumn2.Items.Add(Numbers(i, 2))
        Next i
        For i = 0 To 2
            lstColumn3.Items.Add(Numbers(i, 3))
        Next i
    End Sub

    Private Sub btnCreateArray_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateArray.Click
        'fill the 3 x 4 2-D array with integers
        Randomize()
        For i = 0 To 2
            For j = 0 To 3
                Numbers(i, j) = Int((Rnd() * 100)) + 1
            Next
        Next
    End Sub

    Private Sub btnWriteFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWriteFile.Click
        'Open File to write data
        Filename = InputBox("Please enter a filename")
        FileOpen(1, Filename, OpenMode.Output)
        For i = 0 To 2
            For j = 0 To 3
                WriteLine(1, Numbers(i, j))
            Next
        Next
        FileClose(1)
    End Sub

    Private Sub btnReadFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReadFile.Click
        'Open File to read data
        Filename = InputBox("Please enter a filename")
        FileOpen(1, Filename, OpenMode.Input)
        For i = 0 To 2
            For j = 0 To 3
                Numbers(i, j) = LineInput(1)
            Next
        Next
        FileClose(1)
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        lstColumn0.Items.Clear()
        lstColumn1.Items.Clear()
        lstColumn2.Items.Clear()
        lstColumn3.Items.Clear()
    End Sub
End Class


