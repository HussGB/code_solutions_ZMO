<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCreateArray = New System.Windows.Forms.Button
        Me.lstColumn1 = New System.Windows.Forms.ListBox
        Me.lstColumn2 = New System.Windows.Forms.ListBox
        Me.lstColumn3 = New System.Windows.Forms.ListBox
        Me.lstColumn0 = New System.Windows.Forms.ListBox
        Me.btnDisplayArray = New System.Windows.Forms.Button
        Me.btnWriteFile = New System.Windows.Forms.Button
        Me.btnReadFile = New System.Windows.Forms.Button
        Me.btnClear = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnCreateArray
        '
        Me.btnCreateArray.Location = New System.Drawing.Point(9, 12)
        Me.btnCreateArray.Name = "btnCreateArray"
        Me.btnCreateArray.Size = New System.Drawing.Size(59, 51)
        Me.btnCreateArray.TabIndex = 0
        Me.btnCreateArray.Text = "create and fill array"
        Me.btnCreateArray.UseVisualStyleBackColor = True
        '
        'lstColumn1
        '
        Me.lstColumn1.FormattingEnabled = True
        Me.lstColumn1.Location = New System.Drawing.Point(212, 12)
        Me.lstColumn1.Name = "lstColumn1"
        Me.lstColumn1.Size = New System.Drawing.Size(45, 56)
        Me.lstColumn1.TabIndex = 1
        '
        'lstColumn2
        '
        Me.lstColumn2.FormattingEnabled = True
        Me.lstColumn2.Location = New System.Drawing.Point(254, 12)
        Me.lstColumn2.Name = "lstColumn2"
        Me.lstColumn2.Size = New System.Drawing.Size(45, 56)
        Me.lstColumn2.TabIndex = 2
        '
        'lstColumn3
        '
        Me.lstColumn3.FormattingEnabled = True
        Me.lstColumn3.Location = New System.Drawing.Point(296, 12)
        Me.lstColumn3.Name = "lstColumn3"
        Me.lstColumn3.Size = New System.Drawing.Size(45, 56)
        Me.lstColumn3.TabIndex = 3
        '
        'lstColumn0
        '
        Me.lstColumn0.FormattingEnabled = True
        Me.lstColumn0.Location = New System.Drawing.Point(170, 12)
        Me.lstColumn0.Name = "lstColumn0"
        Me.lstColumn0.Size = New System.Drawing.Size(45, 56)
        Me.lstColumn0.TabIndex = 4
        '
        'btnDisplayArray
        '
        Me.btnDisplayArray.Location = New System.Drawing.Point(89, 12)
        Me.btnDisplayArray.Name = "btnDisplayArray"
        Me.btnDisplayArray.Size = New System.Drawing.Size(59, 51)
        Me.btnDisplayArray.TabIndex = 5
        Me.btnDisplayArray.Text = "display array"
        Me.btnDisplayArray.UseVisualStyleBackColor = True
        '
        'btnWriteFile
        '
        Me.btnWriteFile.Location = New System.Drawing.Point(9, 79)
        Me.btnWriteFile.Name = "btnWriteFile"
        Me.btnWriteFile.Size = New System.Drawing.Size(59, 51)
        Me.btnWriteFile.TabIndex = 6
        Me.btnWriteFile.Text = "send array to file"
        Me.btnWriteFile.UseVisualStyleBackColor = True
        '
        'btnReadFile
        '
        Me.btnReadFile.Location = New System.Drawing.Point(89, 79)
        Me.btnReadFile.Name = "btnReadFile"
        Me.btnReadFile.Size = New System.Drawing.Size(59, 51)
        Me.btnReadFile.TabIndex = 7
        Me.btnReadFile.Text = "read array from file"
        Me.btnReadFile.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(279, 79)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(50, 50)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "clear list boxes"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(356, 160)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnReadFile)
        Me.Controls.Add(Me.btnWriteFile)
        Me.Controls.Add(Me.btnDisplayArray)
        Me.Controls.Add(Me.lstColumn0)
        Me.Controls.Add(Me.lstColumn3)
        Me.Controls.Add(Me.lstColumn2)
        Me.Controls.Add(Me.lstColumn1)
        Me.Controls.Add(Me.btnCreateArray)
        Me.Name = "Form1"
        Me.Text = "2-D array tester"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnCreateArray As System.Windows.Forms.Button
    Friend WithEvents lstColumn1 As System.Windows.Forms.ListBox
    Friend WithEvents lstColumn2 As System.Windows.Forms.ListBox
    Friend WithEvents lstColumn3 As System.Windows.Forms.ListBox
    Friend WithEvents lstColumn0 As System.Windows.Forms.ListBox
    Friend WithEvents btnDisplayArray As System.Windows.Forms.Button
    Friend WithEvents btnWriteFile As System.Windows.Forms.Button
    Friend WithEvents btnReadFile As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button

End Class
