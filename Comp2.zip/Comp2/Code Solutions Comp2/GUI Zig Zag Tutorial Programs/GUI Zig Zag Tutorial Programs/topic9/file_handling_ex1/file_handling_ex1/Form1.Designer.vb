<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtData = New System.Windows.Forms.TextBox
        Me.btnClear = New System.Windows.Forms.Button
        Me.btnWriteFile = New System.Windows.Forms.Button
        Me.btnReadFile = New System.Windows.Forms.Button
        Me.btnDeleteFile = New System.Windows.Forms.Button
        Me.btnAppendFile = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(170, 26)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter text here, then click ""write to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "file"" to send the text to a file"
        '
        'txtData
        '
        Me.txtData.Location = New System.Drawing.Point(20, 58)
        Me.txtData.Multiline = True
        Me.txtData.Name = "txtData"
        Me.txtData.Size = New System.Drawing.Size(165, 43)
        Me.txtData.TabIndex = 1
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(217, 58)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(48, 42)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "clear text"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnWriteFile
        '
        Me.btnWriteFile.Location = New System.Drawing.Point(25, 126)
        Me.btnWriteFile.Name = "btnWriteFile"
        Me.btnWriteFile.Size = New System.Drawing.Size(51, 55)
        Me.btnWriteFile.TabIndex = 3
        Me.btnWriteFile.Text = "write to file"
        Me.btnWriteFile.UseVisualStyleBackColor = True
        '
        'btnReadFile
        '
        Me.btnReadFile.Location = New System.Drawing.Point(93, 126)
        Me.btnReadFile.Name = "btnReadFile"
        Me.btnReadFile.Size = New System.Drawing.Size(49, 55)
        Me.btnReadFile.TabIndex = 4
        Me.btnReadFile.Text = "read from file"
        Me.btnReadFile.UseVisualStyleBackColor = True
        '
        'btnDeleteFile
        '
        Me.btnDeleteFile.Location = New System.Drawing.Point(159, 126)
        Me.btnDeleteFile.Name = "btnDeleteFile"
        Me.btnDeleteFile.Size = New System.Drawing.Size(51, 55)
        Me.btnDeleteFile.TabIndex = 5
        Me.btnDeleteFile.Text = "delete file"
        Me.btnDeleteFile.UseVisualStyleBackColor = True
        '
        'btnAppendFile
        '
        Me.btnAppendFile.Location = New System.Drawing.Point(229, 126)
        Me.btnAppendFile.Name = "btnAppendFile"
        Me.btnAppendFile.Size = New System.Drawing.Size(51, 55)
        Me.btnAppendFile.TabIndex = 6
        Me.btnAppendFile.Text = "append data to file"
        Me.btnAppendFile.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 213)
        Me.Controls.Add(Me.btnAppendFile)
        Me.Controls.Add(Me.btnDeleteFile)
        Me.Controls.Add(Me.btnReadFile)
        Me.Controls.Add(Me.btnWriteFile)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.txtData)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "simple file handling"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtData As System.Windows.Forms.TextBox
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnWriteFile As System.Windows.Forms.Button
    Friend WithEvents btnReadFile As System.Windows.Forms.Button
    Friend WithEvents btnDeleteFile As System.Windows.Forms.Button
    Friend WithEvents btnAppendFile As System.Windows.Forms.Button

End Class
