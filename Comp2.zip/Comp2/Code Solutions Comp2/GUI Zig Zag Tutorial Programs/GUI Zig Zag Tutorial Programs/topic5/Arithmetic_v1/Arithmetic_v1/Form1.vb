Public Class Form1

    Private Sub btnQuestion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuestion.Click
        ' generates a question to the user
        ' and waits for the correct answer

        Dim user_answer As Integer
        Dim correct_answer As Integer

        correct_answer = 4

        Do
            user_answer = InputBox("What is 2 + 2?")
        Loop While user_answer <> correct_answer

        MsgBox("Well done!")

    End Sub
End Class
