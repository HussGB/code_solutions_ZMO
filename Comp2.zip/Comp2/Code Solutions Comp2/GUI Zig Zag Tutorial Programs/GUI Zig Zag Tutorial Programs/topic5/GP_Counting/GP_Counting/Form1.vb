Public Class Form1

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        Dim upper, lower, step_size As Integer
        Dim counter As Integer
        lstOutput.Items.Clear()
        lower = txtLower.Text
        upper = txtUpper.Text
        step_size = txtStep.Text
        For counter = lower To upper Step step_size
            lstOutput.Items.Add(counter)
        Next
    End Sub
End Class
