Public Class Form1

    Private Sub btnTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTable.Click
        Dim counter, multiplier, answer As Integer
        Dim message As String
        lstTable.Items.Clear()
        multiplier = txtTable.Text
        For counter = 1 To 12
            answer = counter * multiplier
            message = counter & " x " & multiplier & " = " & answer
            lstTable.Items.Add(message)
        Next
    End Sub
End Class
