<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtTable = New System.Windows.Forms.TextBox
        Me.btnTable = New System.Windows.Forms.Button
        Me.lstTable = New System.Windows.Forms.ListBox
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(29, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(131, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Which table do you want?"
        '
        'txtTable
        '
        Me.txtTable.Location = New System.Drawing.Point(190, 21)
        Me.txtTable.Name = "txtTable"
        Me.txtTable.Size = New System.Drawing.Size(43, 20)
        Me.txtTable.TabIndex = 1
        '
        'btnTable
        '
        Me.btnTable.Location = New System.Drawing.Point(32, 60)
        Me.btnTable.Name = "btnTable"
        Me.btnTable.Size = New System.Drawing.Size(61, 46)
        Me.btnTable.TabIndex = 2
        Me.btnTable.Text = "display table"
        Me.btnTable.UseVisualStyleBackColor = True
        '
        'lstTable
        '
        Me.lstTable.FormattingEnabled = True
        Me.lstTable.Location = New System.Drawing.Point(119, 62)
        Me.lstTable.Name = "lstTable"
        Me.lstTable.Size = New System.Drawing.Size(149, 147)
        Me.lstTable.TabIndex = 3
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(294, 233)
        Me.Controls.Add(Me.lstTable)
        Me.Controls.Add(Me.btnTable)
        Me.Controls.Add(Me.txtTable)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Multiplication Tables"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtTable As System.Windows.Forms.TextBox
    Friend WithEvents btnTable As System.Windows.Forms.Button
    Friend WithEvents lstTable As System.Windows.Forms.ListBox

End Class
