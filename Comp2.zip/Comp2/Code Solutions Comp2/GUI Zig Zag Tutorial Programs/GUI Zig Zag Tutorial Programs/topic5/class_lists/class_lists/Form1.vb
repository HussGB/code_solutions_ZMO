Public Class Form1

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        Dim counter As Integer
        Dim initial, name As String
        lstNames.Items.Clear()
        counter = 0
        Do
            name = InputBox("Enter a name (or END)")
            If UCase(name) <> "END" Then lstNames.Items.Add(name)
            initial = Mid$(name, 1, 1)
            If UCase(initial) = "A" Then counter = counter + 1
        Loop Until (name = "END") Or (name = "end")
        lstNames.Items.Add(counter)

    End Sub
End Class
