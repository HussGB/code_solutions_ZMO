Public Class Form1

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        'generates lists of random numbers

        Dim number As Single
        Dim counter As Integer
        Randomize()

        lstRandoms.Items.Clear()

        For counter = 1 To 10
            number = Int(Rnd() * 10) + 1
            lstRandoms.Items.Add(number)
        Next
    End Sub
End Class
