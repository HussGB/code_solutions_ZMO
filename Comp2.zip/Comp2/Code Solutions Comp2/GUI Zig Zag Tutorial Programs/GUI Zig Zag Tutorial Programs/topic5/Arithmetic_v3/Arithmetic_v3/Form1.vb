Public Class Form1

    Private Sub btnQuestion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuestion.Click
        ' generates 6 random question to the user
        ' and waits for the correct answer

        Dim user_answer, correct_answer As Integer
        Dim first, second As Integer
        Dim counter As Integer
        Dim question As Integer

        Randomize()
        For question = 1 To 6
            first = Int(Rnd() * 10) + 1
            second = Int(Rnd() * 10) + 1
            counter = 0
            correct_answer = first + second

            Do
                user_answer = InputBox("What is " & first & " + " & second & "?", "Question" & question)
                counter = counter + 1
                If user_answer <> correct_answer Then MsgBox("Wrong, try again!")
            Loop Until user_answer = correct_answer
            MsgBox("Well done!  You took " & counter & " tries")
        Next

    End Sub
End Class
