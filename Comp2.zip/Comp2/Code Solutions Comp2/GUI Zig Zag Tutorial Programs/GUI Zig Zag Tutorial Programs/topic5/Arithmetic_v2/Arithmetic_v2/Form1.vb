Public Class Form1

    Private Sub btnQuestion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuestion.Click
        ' version 2
        ' generates a question to the user, gives feedback,
        ' and waits for the correct answer

        Dim user_answer, correct_answer As Integer
        Dim counter As Integer

        correct_answer = 4
        counter = 0

        Do
            user_answer = InputBox("What is 2 + 2?")
            counter = counter + 1
            If user_answer <> correct_answer Then MsgBox("Wrong, try again")
        Loop Until user_answer = correct_answer

        MsgBox("Well done - you got the right answer in " & counter & " tries")

    End Sub
End Class
