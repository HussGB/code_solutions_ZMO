Public Class Form1

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        Dim counter As Integer
        For counter = 28 To 16 Step -2
            lstOutput.Items.Clear()
            lstOutput.Font = New System.Drawing.Font("Comic Sans", counter)
            lstOutput.Items.Add("This is Comic Sans, size " & counter)
            MsgBox("continue?")
        Next
    End Sub
End Class
