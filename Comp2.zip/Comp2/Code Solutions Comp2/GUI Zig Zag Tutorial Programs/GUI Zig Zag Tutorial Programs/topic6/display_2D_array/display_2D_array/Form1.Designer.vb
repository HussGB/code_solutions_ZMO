<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDataEntry = New System.Windows.Forms.Button
        Me.lstColumn1 = New System.Windows.Forms.ListBox
        Me.lstColumn2 = New System.Windows.Forms.ListBox
        Me.lstColumn3 = New System.Windows.Forms.ListBox
        Me.lstColumn0 = New System.Windows.Forms.ListBox
        Me.SuspendLayout()
        '
        'btnDataEntry
        '
        Me.btnDataEntry.Location = New System.Drawing.Point(9, 12)
        Me.btnDataEntry.Name = "btnDataEntry"
        Me.btnDataEntry.Size = New System.Drawing.Size(67, 51)
        Me.btnDataEntry.TabIndex = 0
        Me.btnDataEntry.Text = "click to enter data"
        Me.btnDataEntry.UseVisualStyleBackColor = True
        '
        'lstColumn1
        '
        Me.lstColumn1.FormattingEnabled = True
        Me.lstColumn1.Location = New System.Drawing.Point(133, 12)
        Me.lstColumn1.Name = "lstColumn1"
        Me.lstColumn1.Size = New System.Drawing.Size(45, 56)
        Me.lstColumn1.TabIndex = 1
        '
        'lstColumn2
        '
        Me.lstColumn2.FormattingEnabled = True
        Me.lstColumn2.Location = New System.Drawing.Point(184, 12)
        Me.lstColumn2.Name = "lstColumn2"
        Me.lstColumn2.Size = New System.Drawing.Size(45, 56)
        Me.lstColumn2.TabIndex = 2
        '
        'lstColumn3
        '
        Me.lstColumn3.FormattingEnabled = True
        Me.lstColumn3.Location = New System.Drawing.Point(235, 12)
        Me.lstColumn3.Name = "lstColumn3"
        Me.lstColumn3.Size = New System.Drawing.Size(45, 56)
        Me.lstColumn3.TabIndex = 3
        '
        'lstColumn0
        '
        Me.lstColumn0.FormattingEnabled = True
        Me.lstColumn0.Location = New System.Drawing.Point(82, 12)
        Me.lstColumn0.Name = "lstColumn0"
        Me.lstColumn0.Size = New System.Drawing.Size(45, 56)
        Me.lstColumn0.TabIndex = 4
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 190)
        Me.Controls.Add(Me.lstColumn0)
        Me.Controls.Add(Me.lstColumn3)
        Me.Controls.Add(Me.lstColumn2)
        Me.Controls.Add(Me.lstColumn1)
        Me.Controls.Add(Me.btnDataEntry)
        Me.Name = "Form1"
        Me.Text = "2-D array of integers"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnDataEntry As System.Windows.Forms.Button
    Friend WithEvents lstColumn1 As System.Windows.Forms.ListBox
    Friend WithEvents lstColumn2 As System.Windows.Forms.ListBox
    Friend WithEvents lstColumn3 As System.Windows.Forms.ListBox
    Friend WithEvents lstColumn0 As System.Windows.Forms.ListBox

End Class
