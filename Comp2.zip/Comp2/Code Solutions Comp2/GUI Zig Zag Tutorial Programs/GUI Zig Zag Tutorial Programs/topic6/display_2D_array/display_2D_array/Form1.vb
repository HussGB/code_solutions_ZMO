Public Class Form1

    Private Sub btnDataEntry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataEntry.Click
        Dim Numbers(2, 3) As Integer
        Dim i As Integer
        Dim j As Integer

        'Input values

        For i = 0 To 2
            For j = 0 To 3
                Numbers(i, j) = InputBox("please enter value for row " & i & " column " & j)
            Next j
        Next i

        'Display array in 4 list boxes

        For i = 0 To 2
            lstColumn0.Items.Add(Numbers(i, 0))
        Next i
        For i = 0 To 2
            lstColumn1.Items.Add(Numbers(i, 1))
        Next i
        For i = 0 To 2
            lstColumn2.Items.Add(Numbers(i, 2))
        Next i
        For i = 0 To 2
            lstColumn3.Items.Add(Numbers(i, 3))
        Next i
    End Sub


End Class
