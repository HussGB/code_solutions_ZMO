Public Class Form1

    Structure CountryType
        Dim CountryName As String
        Dim Population As Single
        Dim Capital As String
        Dim GDP As Single
        Dim WorldRanking As Integer
        Dim Democracy As Boolean
    End Structure

    Private Sub btnDataEntry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataEntry.Click

        Dim Countries(2) As CountryType

        Dim row As Integer

        'Input values
        For row = 0 To 2
            Countries(row).CountryName = InputBox("Row " & row & ": Enter name of country")
            Countries(row).Population = InputBox("Row " & row & ": Enter population (millions)")
            Countries(row).Capital = InputBox("Row " & row & ": Enter capital city")
            Countries(row).GDP = InputBox("Row " & row & ": Enter GDP(�millions)")
            Countries(row).WorldRanking = InputBox("Row " & row & ": GDP World Ranking")
            Countries(row).Democracy = InputBox("Row " & row & ": Democracy (0 for No, -1 for Yes)?")
        Next row

        'Display names of records which match the criteria in list box
        For row = 0 To 2
            If Countries(row).WorldRanking < 100 Then lstOutput.Items.Add(Countries(row).CountryName)
        Next row

    End Sub


End Class
