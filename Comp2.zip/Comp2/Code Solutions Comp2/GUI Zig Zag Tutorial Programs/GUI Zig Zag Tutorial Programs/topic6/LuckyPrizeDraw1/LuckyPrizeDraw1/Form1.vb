Public Class Form1

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        'declare variables
        Dim index, chosen As Integer
        Dim stored_name(9) As String
        'get names from user
        For index = 0 To 9
            stored_name(index) = InputBox("Enter a name")
        Next
        'make a random selection
        Randomize()
        chosen = Int(Rnd() * 10) + 1
        'display the winner's name
        txtWinner.Text = stored_name(chosen)
    End Sub
End Class
