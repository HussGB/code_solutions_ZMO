Public Class Form1
    Dim int_array(9) As Integer

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        lstIndex.Items.Clear()
        lstElement.Items.Clear()
    End Sub

    Private Sub btnCreateArray_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateArray.Click
        'fill a 10 element 1-D array with integers
        Dim index As Integer
        For index = 0 To 9
            int_array(index) = Int((Rnd() * 100)) + 1
        Next
    End Sub

    Private Sub btnDisplayArray_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplayArray.Click
        'display a 1-D array in 2 list boxes
        Dim index As Integer
        For index = 0 To 9
            lstIndex.Items.Add(index)
            lstElement.Items.Add(int_array(index))
        Next
    End Sub
End Class
