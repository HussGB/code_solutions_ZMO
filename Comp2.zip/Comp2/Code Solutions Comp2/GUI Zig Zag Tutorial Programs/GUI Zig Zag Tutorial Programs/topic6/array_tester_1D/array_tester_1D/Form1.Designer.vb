<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCreateArray = New System.Windows.Forms.Button
        Me.btnDisplayArray = New System.Windows.Forms.Button
        Me.btnClear = New System.Windows.Forms.Button
        Me.lstIndex = New System.Windows.Forms.ListBox
        Me.lstElement = New System.Windows.Forms.ListBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'btnCreateArray
        '
        Me.btnCreateArray.Location = New System.Drawing.Point(12, 12)
        Me.btnCreateArray.Name = "btnCreateArray"
        Me.btnCreateArray.Size = New System.Drawing.Size(56, 54)
        Me.btnCreateArray.TabIndex = 0
        Me.btnCreateArray.Text = "create and fill array"
        Me.btnCreateArray.UseVisualStyleBackColor = True
        '
        'btnDisplayArray
        '
        Me.btnDisplayArray.Location = New System.Drawing.Point(12, 86)
        Me.btnDisplayArray.Name = "btnDisplayArray"
        Me.btnDisplayArray.Size = New System.Drawing.Size(56, 54)
        Me.btnDisplayArray.TabIndex = 1
        Me.btnDisplayArray.Text = "display array"
        Me.btnDisplayArray.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(12, 166)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(56, 54)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "clear list boxes"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lstIndex
        '
        Me.lstIndex.FormattingEnabled = True
        Me.lstIndex.Location = New System.Drawing.Point(118, 34)
        Me.lstIndex.Name = "lstIndex"
        Me.lstIndex.Size = New System.Drawing.Size(56, 186)
        Me.lstIndex.TabIndex = 3
        '
        'lstElement
        '
        Me.lstElement.FormattingEnabled = True
        Me.lstElement.Location = New System.Drawing.Point(202, 34)
        Me.lstElement.Name = "lstElement"
        Me.lstElement.Size = New System.Drawing.Size(56, 186)
        Me.lstElement.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(123, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "index                   element"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 244)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lstElement)
        Me.Controls.Add(Me.lstIndex)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnDisplayArray)
        Me.Controls.Add(Me.btnCreateArray)
        Me.Name = "Form1"
        Me.Text = "Array tester"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCreateArray As System.Windows.Forms.Button
    Friend WithEvents btnDisplayArray As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents lstIndex As System.Windows.Forms.ListBox
    Friend WithEvents lstElement As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
