Public Class Form1

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        'prompts the user to enter 10 names and towns
        'then 4 prizes
        'then selects one person and one prize at random

        Dim index As Integer
        Dim winner As Integer
        Dim prize As Integer
        Dim stored_name(9) As String
        Dim stored_town(9) As String
        Dim stored_prize(3) As String

        For index = 0 To 9
            stored_name(index) = InputBox("Enter name " & index + 1)
            stored_town(index) = InputBox(" and the town where they live ..")
        Next

        For index = 0 To 3
            stored_prize(index) = InputBox("Enter prize " & index + 1)
        Next

        Randomize()
        winner = Int(Rnd * 10) + 1
        prize = Int(Rnd * 4) + 1

        txtWinner.Text = stored_name(winner) & " of " & stored_town(winner) & _
          " has won a " & stored_prize(prize)
    End Sub

End Class
