Public Class Form1
    Structure MemberType
        Dim MemberNumber As Integer
        Dim Surname As String
        Dim Forename As String
        Dim FullMember As Boolean
        Dim Owed As Single
    End Structure

    Private Sub btnDataEntry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataEntry.Click

        Dim Members(4) As MemberType

        Dim row As Integer
        Dim chosen As Integer

        'Input values

        For row = 0 To 4
            Members(row).MemberNumber = InputBox("Row " & row & ": Enter membership number")
            Members(row).Surname = InputBox("Row " & row & ": Enter surname")
            Members(row).Forename = InputBox("Row " & row & ": Enter forename")
            Members(row).FullMember = InputBox("Row " & row & ": Full member (0 for No, -1 for Yes)?")
            Members(row).Owed = InputBox("Row " & row & ": Enter amount owed(�)")
        Next row

        'ask user to identify record to be displayed
        chosen = InputBox("Which row of the table do you want to display?")


        'Display chosen record in picture box
        txtNumber.Text = Members(chosen).MemberNumber
        txtName.Text = Members(chosen).Forename + " " + Members(chosen).Surname
        If Members(chosen).FullMember Then txtFull.Text = "Y" Else txtFull.Text = "N"
        txtOwed.Text = Members(chosen).Owed

    End Sub
End Class
