<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDataEntry = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtNumber = New System.Windows.Forms.TextBox
        Me.txtName = New System.Windows.Forms.TextBox
        Me.txtFull = New System.Windows.Forms.TextBox
        Me.txtOwed = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'btnDataEntry
        '
        Me.btnDataEntry.Location = New System.Drawing.Point(10, 13)
        Me.btnDataEntry.Name = "btnDataEntry"
        Me.btnDataEntry.Size = New System.Drawing.Size(64, 58)
        Me.btnDataEntry.TabIndex = 0
        Me.btnDataEntry.Text = "click to enter data"
        Me.btnDataEntry.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(99, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 130)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Member number:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Name:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Full member?" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Amount owed:"
        '
        'txtNumber
        '
        Me.txtNumber.Location = New System.Drawing.Point(196, 15)
        Me.txtNumber.Name = "txtNumber"
        Me.txtNumber.Size = New System.Drawing.Size(117, 20)
        Me.txtNumber.TabIndex = 2
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(196, 51)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(117, 20)
        Me.txtName.TabIndex = 3
        '
        'txtFull
        '
        Me.txtFull.Location = New System.Drawing.Point(196, 92)
        Me.txtFull.Name = "txtFull"
        Me.txtFull.Size = New System.Drawing.Size(117, 20)
        Me.txtFull.TabIndex = 4
        '
        'txtOwed
        '
        Me.txtOwed.Location = New System.Drawing.Point(196, 132)
        Me.txtOwed.Name = "txtOwed"
        Me.txtOwed.Size = New System.Drawing.Size(117, 20)
        Me.txtOwed.TabIndex = 5
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(325, 164)
        Me.Controls.Add(Me.txtOwed)
        Me.Controls.Add(Me.txtFull)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.txtNumber)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnDataEntry)
        Me.Name = "Form1"
        Me.Text = "club membership records"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnDataEntry As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtFull As System.Windows.Forms.TextBox
    Friend WithEvents txtOwed As System.Windows.Forms.TextBox

End Class
