Public Class Form1

    Private Sub btnPassword_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPassword.Click

        'coding for the Password button click event
        'using a user-defined function
        'by A. Programmer on 29/04/09

        Dim name1 As String, name2 As String, year As String
        Dim colour As String, street As String, shoe_size As String
        Dim password As String

        'prompt the user to enter the required information 
        name1 = InputBox("Enter your first name")
        name2 = InputBox("Enter your second name")
        year = InputBox("Enter your year of birth (in the form 1987 or 2001)")
        colour = InputBox("Enter your favourite colour")
        street = InputBox("Enter your street")
        shoe_size = InputBox("Enter your shoe size")

        'create the password 
        password = pass(name1, name2, year, colour, street, shoe_size)

        'display the password 
        MsgBox("Your password is " & password)

    End Sub

    Function pass(ByVal A As String, ByVal B As String, ByVal C As String, ByVal D As String, ByVal E As String, ByVal F As String) As String
        'create the password 
        A = Mid$(A, 1, 1)
        B = Mid$(B, 2, 1)
        C = Mid$(C, 3, 2)
        D = Mid$(D, 2, 2)
        E = Mid$(E, 1, 3)
        Return (A + B + C + D + E + F)
    End Function

End Class
