Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim Euros As Integer
        Dim Exchange_rate As Single
        Dim Pounds As Single
        Euros = InputBox("Enter a whole number of Euros")
        Exchange_rate = InputBox("How many pounds = 1 Euro")
        Pounds = E_to_P(Euros, Exchange_rate)
        MsgBox("You get " & Format(Pounds, "currency"))

    End Sub
    Function E_to_P(ByVal Euros As Integer, ByVal Ex_rate As Single) As Single

        ' function to convert Euros to Pounds

        Dim Pounds As Single

        Pounds = Euros * Ex_rate * 0.95

        Return Pounds
    End Function


End Class
