﻿Imports System.IO
Public Class Staff

    Private Structure Staff
        Public StaffID As String
        Public FirstName As String
        Public Surname As String
        Public HomeAdd As String
        Public ParkingPermit As String
    End Structure
    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Dim StaffData As Staff
        Dim sw As New System.IO.StreamWriter("staffdetails.txt", True)


        'Validation length check
        If txtStaffID.Text.Length > 50 Then MsgBox("Too many charactors in Staff ID") : sw.Close() : Exit Sub
        If txtFirstName.Text.Length > 50 Then MsgBox("Too many Characters in Firstname") : sw.Close() : Exit Sub
        If txtSurname.Text.Length > 50 Then MsgBox("Too many Characters in surname") : sw.Close() : Exit Sub



        'Presence check
        If txtStaffID.Text = "" Then MsgBox("StaffID Field Blank") : sw.Close() : Exit Sub
        If txtFirstName.Text = "" Then MsgBox("First Name Field Blank") : sw.Close() : Exit Sub
        If txtSurname.Text = "" Then MsgBox("Surname Field Blank") : sw.Close() : Exit Sub
        If txtHomeAdd.Text = "" Then MsgBox("Home Address Field Blank") : sw.Close() : Exit Sub
        If txtParkingPermit.Text = "" Then MsgBox("ParkingPermit Field Blank") : sw.Close() : Exit Sub


        StaffData.StaffID = LSet(txtStaffID.Text, 50)
        StaffData.FirstName = LSet(txtFirstName.Text, 50)
        StaffData.Surname = LSet(txtSurname.Text, 50)
        StaffData.HomeAdd = LSet(txtHomeAdd.Text, 50)
        StaffData.ParkingPermit = LSet(txtParkingPermit.Text, 50)

        sw.WriteLine(StaffData.StaffID & StaffData.FirstName & StaffData.Surname & StaffData.HomeAdd & StaffData.ParkingPermit)
        sw.Close()
        MsgBox("File saved! ")

    End Sub

    Private Sub Staff_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Dir$("staffdetails.txt") = "" Then
            Dim sw As New System.IO.StreamWriter("staffdetails.txt", True)
            sw.Close()
            MsgBox("A new file has been created!", vbExclamation, "Warning!")

        End If
    End Sub

    Private Sub cmdCount_Click(sender As Object, e As EventArgs) Handles cmdCount.Click
        Dim countGot As Integer = 0
        Dim totalCount As Integer = 0

        Dim staffdata() As String = File.ReadAllLines("staffdetails.txt")

        For i = 0 To UBound(staffdata)
            countGot = 0

            If Trim(Mid(staffdata(i), 1, 50)) = txtStaffID.Text And Not txtStaffID.Text = "" Then countGot += 1
            If Trim(Mid(staffdata(i), 51, 50)) = txtFirstName.Text And Not txtFirstName.Text = "" Then countGot += 1
            If Trim(Mid(staffdata(i), 101, 50)) = txtSurname.Text And Not txtSurname.Text = "" Then countGot += 1
            If Trim(Mid(staffdata(i), 151, 50)) = txtHomeAdd.Text And Not txtHomeAdd.Text = "" Then countGot += 1
            If Trim(Mid(staffdata(i), 201, 50)) = txtParkingPermit.Text And Not txtParkingPermit.Text = "" Then countGot += 1

            If countGot > 0 Then
                totalCount += 1
            End If
        Next

        MsgBox("There were " & totalCount & " Records found")

    End Sub


    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        Dim found As Boolean = False
        Dim StaffData() As String = File.ReadAllLines(("staffdetails.txt")) 'read all lines/records into array moviedata

        For I = 0 To UBound(StaffData) 'loop from i = 0 to the number of lines in the file/ubound returns the highest element value
            If (Trim(Mid(StaffData(I), 1, 50)) = txtStaffID.Text) Then
                found = True
                MsgBox("Entry Found! ")
                txtStaffID.Text = Trim(Mid(StaffData(I), 1, 50))
                txtFirstName.Text = Trim(Mid(StaffData(I), 51, 50))
                txtSurname.Text = Trim(Mid(StaffData(I), 101, 50))
                txtHomeAdd.Text = Trim(Mid(StaffData(I), 151, 50))
                txtParkingPermit.Text = Trim(Mid(StaffData(I), 201, 50))
            End If

        Next I

        If found = False Then
            MsgBox("Entry not found!")
        End If
    End Sub


    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Dim title As String
        title = "TEST"
        If title <> "MR" And title <> "DR" And title <> "TEST" Then
            MsgBox("ERROR")
        End If

    End Sub
End Class