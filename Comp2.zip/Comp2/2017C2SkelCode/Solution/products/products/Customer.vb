﻿Imports System.IO
Public Class Customer

    Private Structure Customer

        Dim customerID As String
        Dim firstname As String
        Dim surname As String
        Dim postcode As String
        Dim DOB As String
        Dim pointsCollected As String

    End Structure

    Private Sub Customer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Dir$("customerdetails.txt") = "" Then
            Dim sw As New System.IO.StreamWriter("customerdetails.txt", True)
            sw.Close()
            MsgBox("A new file has been created ", vbExclamation, "Warning!")
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim customerData As Customer
        Dim intCheck As Integer

        Dim sw As New System.IO.StreamWriter("customerdetails.txt", True)
        'presence check
        If txtCustomerID.Text = "" Then MsgBox("CustomerID field is blank") : sw.Close() : Exit Sub
        If txtPoints.Text = "" Then MsgBox("Points field is blank") : sw.Close() : Exit Sub
        If txtDob.Text = "" Then MsgBox("DOB field is blank") : sw.Close() : Exit Sub

        'Length Check
        If txtFirstname.Text.Length > 50 Then MsgBox("Firstname field too long") : sw.Close() : Exit Sub
        'Format Check 
        If txtDob.Text(2) <> "/" Or txtDob.Text(5) <> "/" Then MsgBox("DOB format incorrect. Must be in form of dd/mm/yyyy") : sw.Close() : Exit Sub
        'Type Check
        If Integer.TryParse(txtPoints.Text, intCheck) = False Then MsgBox("Please enter a valid number in points") : sw.Close() : Exit Sub
        'Range Check
        If CInt(txtPoints.Text) < 0 Or CInt(txtPoints.Text) > 1000 Then MsgBox("Points value incorrect") : sw.Close() : Exit Sub
        customerData.customerID = LSet(txtCustomerID.Text, 50)
        customerData.firstname = LSet(txtFirstname.Text, 50)
        customerData.surname = LSet(txtSurname.Text, 50)
        customerData.postcode = LSet(txtPostcode.Text, 50)
        customerData.DOB = LSet(txtDob.Text, 50)
        customerData.pointsCollected = LSet(txtPoints.Text, 50)


        sw.WriteLine(customerData.customerID & customerData.firstname & customerData.surname & customerData.postcode & customerData.DOB & customerData.pointsCollected)
        sw.Close()
        MsgBox("File Saved")

        End Sub

    Private Sub btnCount_Click(sender As Object, e As EventArgs) Handles btnCount.Click
        Dim gotCount As Integer = 0
        Dim totalCount As Integer = 0
        Dim customerdata() As String = File.ReadAllLines("Customerdetails.txt")

        For i = 0 To UBound(customerdata)
            If Trim(Mid(customerdata(i), 1, 50)) = txtCustomerID.Text And txtCustomerID.Text <> "" Then gotCount += 1
            If Trim(Mid(customerdata(i), 51, 50)) = txtFirstname.Text And txtFirstname.Text <> "" Then gotCount += 1
            If Trim(Mid(customerdata(i), 101, 50)) = txtSurname.Text And txtSurname.Text <> "" Then gotCount += 1
            If Trim(Mid(customerdata(i), 151, 50)) = txtPostcode.Text And txtPostcode.Text <> "" Then gotCount += 1
            If Trim(Mid(customerdata(i), 201, 50)) = txtDob.Text And txtDob.Text <> "" Then gotCount += 1
            If Trim(Mid(customerdata(i), 251, 50)) = txtPoints.Text And txtPoints.Text <> "" Then gotCount += 1
            If gotCount > 0 Then totalCount += 1

        Next

        MsgBox("There were: " & totalCount & " customers found")
    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        Dim found As Boolean = False
        Dim customerdata() As String = File.ReadAllLines("Customerdetails.txt")
        For i = 0 To UBound(customerdata)
            If Trim(Mid(customerdata(i), 1, 50)) = txtCustomerID.Text Then
                found = True
                MsgBox("Found")
                txtFirstname.Text = Trim(Mid(customerdata(i), 51, 50))
                txtSurname.Text = Trim(Mid(customerdata(i), 101, 50))
                txtPostcode.Text = Trim(Mid(customerdata(i), 151, 50))
                txtDob.Text = Trim(Mid(customerdata(i), 201, 50))
                txtPoints.Text = Trim(Mid(customerdata(i), 251, 50))
            End If
        Next

        If found = False Then
            MsgBox("Not Found")
        End If

    End Sub
End Class