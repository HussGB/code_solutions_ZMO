﻿Imports System.IO

Public Class products


    '    . . . Means missing or broken code. Complete this code.

    Private Structure product
        Public ProductID As String
        Public ProductLocation As String
        Public ProductName As String
        Public ProductDescription As String
        Public ProductPrice As String
    End Structure


    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        Dim ProductData As New product
        Dim sw As New System.IO.StreamWriter("products.txt", True)
        ProductData.ProductID = LSet(txtproductID.Text, 50)
        ProductData.ProductLocation = LSet(txtProductLocation.Text, 50)
        ProductData.ProductName = LSet(txtProductName.Text, 50)
        ProductData.ProductDescription = LSet(txtProductDescription.Text, 50)
        ProductData.ProductPrice = LSet(txtProductPrice.Text, 50)

        sw.WriteLine(ProductData.ProductID & ProductData.ProductLocation & ProductData.ProductName & ProductData.ProductDescription & ProductData.ProductPrice)
        sw.Close()
        MsgBox("File Saved!")

    End Sub

    Private Sub products_Load() Handles MyBase.Load
        If Dir$("products.txt") = "" Then
            Dim sw As New StreamWriter("products.txt", True)
            sw.WriteLine("")
            sw.Close()
            MsgBox("A new file has been created", vbExclamation, "Warning!")
        End If
    End Sub

    Private Sub cmdCount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCount.Click
        Dim CountGot As Integer
        CountGot = 0
        Dim ProductCount As Integer
        ProductCount = 0

        Dim ProductData() As String = File.ReadAllLines("products.txt")
        For i = 0 To UBound(ProductData)

            CountGot = 0
            If Trim(Mid(ProductData(i), 1, 50)) = txtproductID.Text And Not txtproductID.Text = "" Then CountGot = CountGot + 1
            If Trim(Mid(ProductData(i), 51, 50)) = txtProductLocation.Text And Not txtProductLocation.Text = "" Then CountGot = CountGot + 1
            If Trim(Mid(ProductData(i), 101, 50)) = txtProductName.Text And Not txtProductName.Text = "" Then CountGot = CountGot + 1
            If Trim(Mid(ProductData(i), 151, 50)) = txtProductDescription.Text And Not txtProductDescription.Text = "" Then CountGot = CountGot + 1
            If Trim(Mid(ProductData(i), 201, 50)) = txtProductPrice.Text And Not txtProductPrice.Text = "" Then CountGot = CountGot + 1
            If CountGot > 0 Then ProductCount = ProductCount = ProductCount + 1
        Next i
        MsgBox("There were: " & ProductCount & " items found")

    End Sub

    Private Sub CustomerBtn_Click(sender As Object, e As EventArgs) Handles CustomerBtn.Click
        Customer.Show()
        Me.Hide()
    End Sub
End Class
