﻿Public Class TempControls
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        If CInt(txtTemp.Text) = 100 Then MsgBox("Program Terminated") : Me.Close()


    End Sub
End Class