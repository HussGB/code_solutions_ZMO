﻿Public Class TempControl
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim Temp As Single = txtTemp.Text
        If Temp = 100 Then
            MsgBox("Program Terminated")
            Exit Sub
        ElseIf Temp > -2.1 Then
            MsgBox("Too High")
        ElseIf Temp <= -2.1 And Temp >= -4.0 Then
            MsgBox("Suitable for general skating")
        ElseIf Temp <= -4.1 And Temp >= -5.5 Then
            MsgBox("Suitable for competition skating")
        ElseIf Temp <= 5.6 And Temp >= -9.0 Then
            MsgBox("Suitable for ice Hockey")
        ElseIf Temp < -9.0 Then
            MsgBox("Fault Detected")
        Else
            MsgBox("Incorrect Input")
        End If

        Dim sw As New System.IO.StreamWriter("iceResult.txt", True)
        sw.WriteLine(Temp)
        sw.Close()
        MsgBox("Data Saved!")

    End Sub


    Private Sub BtnRetrieve_Click(sender As Object, e As EventArgs) Handles BtnRetrieve.Click
        Dim tempratures() As String = System.IO.File.ReadAllLines("iceResult.txt")
        Dim lastVal As Integer = UBound(tempratures)

        txtLastResult.Text = tempratures(lastVal)

    End Sub
End Class