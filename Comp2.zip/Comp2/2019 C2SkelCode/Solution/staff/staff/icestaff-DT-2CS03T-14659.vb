﻿Imports System.IO

Public Class icestaff

    Private Structure staffDetails
        Public staffID As String
        Public firstName As String
        Public surname As String
        Public postcode As String

    End Structure


    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        Dim staffData As New staffDetails
        Dim sw As New System.IO.StreamWriter("staff.txt", True)
        staffData.staffID = LSet(txtStaffID.Text, 50)
        staffData.firstName = LSet(txtFirstName.Text, 50)
        staffData.surname = LSet(txtSurname.Text, 50)
        staffData.postcode = LSet(txtPostcode.Text, 50)

        sw.WriteLine(staffData.staffID & staffData.firstName & staffData.surname & staffData.postcode)
        sw.Close()
        MsgBox("File Saved!")

    End Sub

    Private Sub staff_Load() Handles MyBase.Load
        If Dir$("staff.txt") = "" Then
            Dim sw As New StreamWriter("staff.txt", True)
            sw.WriteLine("")
            sw.Close()
            MsgBox("A New file has been created", vbExclamation, "Note")
        End If
    End Sub

    Private Sub btnCount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCount.Click 
        Dim CountGot As Integer
        CountGot = 0
        Dim staffCount As Integer
        staffCount = 0

        Dim staffData() As String = File.ReadAllLines("Staff.txt")
        For i = 0 To UBound(staffData)

            CountGot = 0
            If Trim(Mid(staffData(i), 1, 50)) = txtStaffID.Text And Not txtStaffID.Text = "" Then CountGot = CountGot + 1
            If Trim(Mid(staffData(i), 51, 50)) = txtFirstName.Text And Not txtFirstName.Text = "" Then CountGot = CountGot + 1
            If Trim(Mid(staffData(i), 101, 50)) = txtSurname.Text And Not txtSurname.Text = "" Then CountGot = CountGot + 1
            If Trim(Mid(staffData(i), 151, 50)) = txtPostcode.Text And Not txtPostcode.Text = "" Then CountGot = CountGot + 1
            If CountGot > 0 Then staffCount = staffCount + 1
        Next i
        MsgBox("There were: " & staffCount & " staff found")

    End Sub


End Class
