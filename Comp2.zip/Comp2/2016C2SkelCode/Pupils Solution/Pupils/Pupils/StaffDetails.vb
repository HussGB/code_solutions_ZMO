﻿Imports System.IO

Public Class StaffDetails
    Private Structure Staff
        Public staffId As String
        Public FirstName As String
        Public Surname As String
        Public HomeAdd As String                  'Creating the structure that will hold the  data.
        Public EmergencyNo As String
        Public Email As String
    End Structure
    Private Sub StaffDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Dir$("Pupils.txt") = "" Then
            Dim sw As New StreamWriter("Pupils.txt", True)    'This makes sure there is actually a database to enter/read data. If not, it creates a new blank one.
            sw.WriteLine("")
            sw.Close()
            MsgBox("A new file has been created", vbExclamation, "Warning!")
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim StaffData As New Staff
        Dim sw As New System.IO.StreamWriter("Staff.txt", True)




        StaffData.staffId = LSet(txtStaffID.Text, 50)
        StaffData.FirstName = LSet(txtFirstName.Text, 50)
        StaffData.Surname = LSet(txtSurname.Text, 50)
        StaffData.HomeAdd = LSet(txtHomeAdd.Text, 50)                      'Filling the structure with data.
        StaffData.EmergencyNo = LSet(txtEmergencyNo.Text, 50)
        StaffData.Email = LSet(txtEmail.Text, 50)

        sw.WriteLine(StaffData.staffId & StaffData.FirstName & StaffData.Surname & StaffData.HomeAdd & StaffData.EmergencyNo & StaffData.Email)
        sw.Close()                                                                  'Always need to close afterwards
        MsgBox("File Saved!")
    End Sub
End Class